var templatepage = {
    init: function () {
      this.mainCss();
      this.mainJS();
    },
    mainCss: function () {
        var mainCss;

  ;
  var headofdoc = document.getElementsByTagName('head')[0];
  var s = document.createElement('style');
  s.setAttribute('type', 'text/css');
  s.appendChild(document.createTextNode(mainCss));
  headofdoc.appendChild(s);
  
   
  
      
    },
    mainJS: function () {
      
      $("#activefeature").click(function() {
        $([document.documentElement, document.body]).animate({
            scrollTop: $("#feature").offset().top
        }, 2000);
    });
     
    $("#activework").click(function() {
      $([document.documentElement, document.body]).animate({
          scrollTop: $("#work").offset().top
      }, 2000);
  });

  $("#activeteam").click(function() {
    $([document.documentElement, document.body]).animate({
        scrollTop: $("#team").offset().top
    }, 2000);
});


$("#activetest").click(function() {
  $([document.documentElement, document.body]).animate({
      scrollTop: $("#testimonials").offset().top
  }, 2000);
});

$("#activedownload").click(function() {
  $([document.documentElement, document.body]).animate({
      scrollTop: $("#download").offset().top
  }, 2000);
});



$(window).on("scroll",function () {
  if ($(window).scrollTop() > 50) {
    $(".header-container").css("border-bottom", "0px");
    $('.header-top').addClass('sticky-header');
  } else{
    $(".header-container").css("border-bottom", "1px solid rgb(255,255,255)");
    $('.header-top').removeClass('sticky-header');
  }
});

      // toggle menu/navbar script
    $('.menu-btn').click(function(){
      $('.header-top .menu').toggleClass("active");
      $('.menu-btn i').toggleClass("active");
      
  });
  

      $('.flexslider').flexslider({
        animation: "slide",
        animationLoop: true,
        controlsContainer: ".content-wrapper"
        
        
      });
      
    


      $(".workoverlay").click(function() {
        $(".fancybox").fancybox({
          openEffect	: 'none',
          closeEffect	: 'none'
         
        });
      });
      
     


        
      
    }
    
  
   
  
      
  };
  
   
  
   
  
  (function pollForjQuery() {
    if (window.jQuery !== undefined && document.readyState === "complete") {
      try {
        templatepage.init();
      } catch (err) {
        console.log('TRY ERROR: ' + err);
      }
  
   
  
    } else {
      setTimeout(pollForjQuery, 25);
    }
  })();

  